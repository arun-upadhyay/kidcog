import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Alert, Platform, StyleSheet, View, Text, Pressable, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

import CategoryScreen from './src/screens/CategoryScreen';
import PlayZoneScreen from './src/screens/PlayZoneScreen';
import type { GameKey } from './src/playzone/common';
import StartScreen from './src/screens/StartScreen';
import QuizScreen from './src/screens/QuizScreen';
import ResultsScreen from './src/screens/ResultsScreen';
import LoginScreen from './src/screens/LoginScreen';
import HistoryScreen from './src/screens/HistoryScreen';
import ThankYouScreen, { isThankYouPage } from './src/screens/ThankYouScreen';
import LegalScreen, { isLegalPage } from './src/screens/LegalScreen';
import AppMenu from './src/components/AppMenu';
import IdleGuard from './src/components/IdleGuard';
import { AuthProvider, useAuth } from './src/auth/AuthContext';
import { deleteAccount, deleteChildProfile, fetchTest, getParentReport, listChildren, prefetchRound, saveChild, submitAnswers, updateChildAvatar } from './src/api';
import { supabase } from './src/auth/supabase';
import { stopSpeaking } from './src/speech';
import { forgetProgress, loadProgress, recordArcade, recordRound, type ChildProgress, type RoundReward } from './src/progress';
import BreakSheet, { BREAK_AFTER_MS } from './src/components/BreakSheet';
import { colors } from './src/theme';
import type { ChildProfile, HistoricalAssessment, Report, ResponseInput, SavedChildProfile, TestPayload, TraitKey } from './src/types';

/** Completed rounds show results and rewards immediately for every age. */
type Stage = 'start' | 'categories' | 'quiz' | 'results' | 'history' | 'historical_result' | 'playzone';

function messageOf(err: unknown): string {
  return err instanceof Error ? err.message : 'Something went wrong.';
}

function KidCogApp() {
  const { session, loading: authLoading, signOut, updatePassword } = useAuth();
  const [stage, setStage] = useState<Stage>('start');
  const [child, setChild] = useState<ChildProfile | null>(null);
  const [test, setTest] = useState<TestPayload | null>(null);
  const [report, setReport] = useState<Report | null>(null);
  // Categories tried during this visit, from each test's own result. Used only
  // for the explored markers on the category screen; results are never merged.
  const [explored, setExplored] = useState<Report['traits']>([]);
  const [roundCategory, setRoundCategory] = useState<TraitKey>('abstract_concepts');
  const [roundLength, setRoundLength] = useState(2);
  const generationLock = useRef(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedChildren, setSavedChildren] = useState<SavedChildProfile[]>([]);
  const [profilesOwner, setProfilesOwner] = useState<string | null>(null);
  const [profilesError, setProfilesError] = useState<string | null>(null);
  const [profilesAttempt, setProfilesAttempt] = useState(0);
  const parentId = session?.user.id;

  const [sessionId, setSessionId] = useState<string | null>(null);
  const [historyChild, setHistoryChild] = useState<SavedChildProfile | null>(null);
  const [historical, setHistorical] = useState<HistoricalAssessment | null>(null);
  // Stars, stickers and game difficulty for the child playing (kept on this device).
  const [progress, setProgress] = useState<ChildProgress | null>(null);
  const [reward, setReward] = useState<RoundReward | null>(null);
  // A friendly "time for a break" after about 15 minutes of play.
  const playStartedAt = useRef<number | null>(null);
  const [breakOpen, setBreakOpen] = useState(false);

  useEffect(() => {
    if (!child?.id) { setProgress(null); return; }
    let live = true;
    void loadProgress(child.id).then(p => { if (live) setProgress(p); });
    return () => { live = false; };
  }, [child?.id]);

  useEffect(() => {
    let active = true;
    setProfilesOwner(null);
    setProfilesError(null);
    setSavedChildren([]);
    if (!parentId) return;
    void listChildren().then(profiles => {
      if (!active) return;
      setSavedChildren(profiles);
      setProfilesOwner(parentId);
    }).catch(err => { if (active) setProfilesError(messageOf(err)); });
    return () => { active = false; };
  }, [parentId, profilesAttempt]);

  /** Start a test. Every test is its own session with its own result. */
  const beginRound = useCallback(async (profile: ChildProfile, trait: TraitKey, count: number) => {
    if (generationLock.current) return;
    generationLock.current = true;
    setBusy(true);
    setError(null);
    try {
      if (!profile.id) throw new Error('Choose or create a child nickname first.');
      // null: a fresh session, so this test's result never includes earlier tests.
      // The game difficulty this child has reached in this category, if any.
      const level = (await loadProgress(profile.id)).levels[trait];
      const t = await fetchTest(profile.id, null, profile.age, trait, count, level);
      if (!t.questions.length) {
        throw new Error('No questions were generated. Please try again.');
      }
      setChild(profile);
      setTest(t);
      setSessionId(t.sessionId);
      setRoundCategory(trait);
      setRoundLength(count);
      setReward(null);
      playStartedAt.current ??= Date.now();
      setStage('quiz');
    } catch (err) {
      setError(messageOf(err));
    } finally {
      generationLock.current = false;
      setBusy(false);
    }
  }, []);

  const start = useCallback(async (profile: ChildProfile) => {
    setBusy(true); setError(null);
    try {
      const nickname = profile.firstName?.trim() || 'My child';
      const saved = await saveChild(nickname, profile.age ?? 5, profile.avatar);
      const next = { ...profile, id: saved.id, firstName: saved.nickname, avatar: saved.avatar ?? profile.avatar };
      setSavedChildren(current => current.some(item => item.id === saved.id) ? current.map(item => item.id === saved.id ? saved : item) : [...current, saved]);
      setChild(next);
      setSessionId(null);
      setStage('categories');
    } catch (err) { setError(messageOf(err)); }
    finally { setBusy(false); }
  }, []);

  // Opening a category's sheet starts question-making in the background, so the
  // round is usually ready by the time "Let's play" is tapped.
  const previewCategory = useCallback((trait: TraitKey) => {
    if (child?.id) prefetchRound(child.id, child.age ?? 5, trait);
  }, [child?.id, child?.age]);

  const chooseRound = useCallback(async (trait: TraitKey, count: number) => {
    if (!child) return;
    try {
      await beginRound(child, trait, count);
    } catch (err) { setError(messageOf(err)); }
  }, [child, beginRound]);

  /** Start a category straight from its card on the results screen. */
  const tryCategory = useCallback(async (trait: TraitKey, count: number) => {
    if (!child) return;
    stopSpeaking();
    await beginRound(child, trait, count);
  }, [beginRound, child]);

  /** Leave a round part-way: nothing is submitted, back to choosing a category. */
  const leaveQuiz = useCallback(() => {
    stopSpeaking();
    setError(null);
    setTest(null);
    setSessionId(null);
    setStage('categories');
  }, []);

  const chooseCategory = useCallback(() => {
    stopSpeaking();
    setError(null);
    setStage('categories');
  }, []);

  const openPlayZone = useCallback(() => {
    playStartedAt.current ??= Date.now();
    setStage('playzone');
  }, []);

  /** A Play Zone game was won: save its stars and level, and suggest a break after a long spell of play. */
  const finishGame = useCallback((game: GameKey, stars: number, nextLevel: number) => {
    if (child?.id) void recordArcade(child.id, game, stars, nextLevel).then(setProgress).catch(() => {});
    if (playStartedAt.current !== null && Date.now() - playStartedAt.current >= BREAK_AFTER_MS) {
      setBreakOpen(true);
      playStartedAt.current = Date.now();
    }
  }, [child?.id]);

  const finish = useCallback(
    async (responses: ResponseInput[]) => {
      setBusy(true);
      setError(null);
      try {
        // Only this test's answers: the result describes the test just taken.
        if (!sessionId) throw new Error('This assessment session is missing. Start a new session.');
        const r = await submitAnswers({ sessionId, child, responses });
        setReport(r);
        if (child?.id) {
          void recordRound(child.id, roundCategory, r, child.age).then(({ progress: next, reward: won }) => { setProgress(next); setReward(won); }).catch(() => {});
        }
        if (playStartedAt.current !== null && Date.now() - playStartedAt.current >= BREAK_AFTER_MS) {
          setBreakOpen(true);
          playStartedAt.current = Date.now();
        }
        // Scores are back; the written note follows a few seconds later.
        if (r.parentReportPending) {
          getParentReport(sessionId)
            .then(note => setReport(current => current === r ? { ...r, ...note, parentReportPending: false } : current))
            .catch(err => setReport(current => current === r ? { ...r, parentReportPending: false, parentReportError: messageOf(err) } : current));
        }
        setExplored(current => {
          const byKey = new Map(current.map(t => [t.key, t]));
          for (const t of r.traits) if (t.questionCount > 0) byKey.set(t.key, t);
          return [...byKey.values()];
        });
        setStage('results');
      } catch (err) {
        setError(messageOf(err));
      } finally {
        setBusy(false);
      }
    },
    [child, test, sessionId, roundCategory]
  );

  /** Another round for the same child, allowing repeated questions. */
  const reassess = useCallback(async () => {
    if (!child) return;
    stopSpeaking();
    await beginRound(child, roundCategory, roundLength);
  }, [beginRound, child, roundCategory, roundLength]);

  const restart = useCallback(() => {
    stopSpeaking();
    setStage('start');
    setTest(null);
    setReport(null);
    setChild(null);
    setExplored([]);
    setError(null);
    setSessionId(null);
  }, []);

  const logout = useCallback(async () => { restart(); await signOut(); }, [restart, signOut]);

  /**
   * Home from the ☰ menu. During a round this would throw away the child's
   * answers, so ask first (the same question the quiz's own Leave button asks).
   */
  const goHome = useCallback(() => {
    if (busy) return; // a round is being generated or submitted
    const leave = () => { stopSpeaking(); restart(); };
    if (stage !== 'quiz') { leave(); return; }
    const message = 'Answers so far will not be saved.';
    if (Platform.OS === 'web') {
      if (globalThis.confirm(`Leave this activity?\n\n${message}`)) leave();
      return;
    }
    Alert.alert('Leave this activity?', message, [
      { text: 'Keep playing', style: 'cancel' },
      { text: 'Leave', style: 'destructive', onPress: leave },
    ]);
  }, [busy, stage, restart]);
  /** Delete the parent account, then leave this device signed out. */
  const removeAccount = useCallback(async () => {
    const result = await deleteAccount();
    stopSpeaking();
    // The server has already ended every session, so only clear this device.
    // (A normal sign-out would call the server again and fail.)
    setTimeout(() => { restart(); void supabase.auth.signOut({ scope: 'local' }).catch(() => {}); }, 2500);
    return result;
  }, [restart]);
  const openHistory = useCallback((selected: SavedChildProfile) => { setHistoryChild(selected); setHistorical(null); setError(null); setStage('history'); }, []);
  const deleteChild = useCallback(async (selected: SavedChildProfile) => {
    setError(null);
    try {
      await deleteChildProfile(selected.id);
      void forgetProgress(selected.id);
      setSavedChildren(current => current.filter(item => item.id !== selected.id));
      if (child?.id === selected.id) setChild(null);
    } catch (err) { setError(messageOf(err)); throw err; }
  }, [child?.id]);
  // Errors are shown inside the picture picker, so they are rethrown, not set here.
  const changeAvatar = useCallback(async (selected: SavedChildProfile, avatar: string) => {
    const updated = await updateChildAvatar(selected.id, avatar);
    setSavedChildren(current => current.map(item => item.id === updated.id ? updated : item));
    setChild(current => current?.id === updated.id ? { ...current, avatar: updated.avatar ?? undefined } : current);
  }, []);

  if (authLoading || !session) return <LoginScreen />;

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      {/* Signs the parent out after 30 minutes with no taps or clicks. */}
      <IdleGuard signedInAt={session.user.last_sign_in_at} onTimeout={logout}>
      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        {/* Outside every screen's scroll view, so it is always visible. */}
        <AppMenu
          accountEmail={session.user.email ?? 'Signed-in parent'}
          accountProviders={Array.isArray(session.user.app_metadata.providers)
            ? session.user.app_metadata.providers.filter((provider: unknown): provider is string => typeof provider === 'string')
            : [session.user.app_metadata.provider].filter((provider: unknown): provider is string => typeof provider === 'string')}
          accountVerified={Boolean(session.user.email_confirmed_at)}
          accountCreatedAt={session.user.created_at}
          onChangePassword={updatePassword}
          onSignOut={() => void logout()}
          onDeleteAccount={removeAccount}
          onHome={stage === 'start' ? undefined : goHome}
        />
        <View style={styles.root}>
          {stage === 'start' && profilesOwner !== parentId && <View style={{ padding: 32, alignItems: 'center', gap: 16 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: '#60439B' }}>Who’s playing today?</Text>
            {profilesError ? <>
              <Text accessibilityRole="alert" style={{ textAlign: 'center' }}>We couldn’t load your saved players. {profilesError}</Text>
              <Pressable accessibilityRole="button" onPress={() => { setProfilesError(null); setProfilesAttempt(n => n + 1); }} style={{ padding: 16, borderRadius: 16, backgroundColor: '#EEE9FF' }}>
                <Text style={{ fontWeight: '800', color: '#60439B' }}>Try again</Text>
              </Pressable>
            </> : <><ActivityIndicator color="#7650C7" /><Text>Loading your saved players…</Text></>}
          </View>}
          {stage === 'start' && profilesOwner === parentId && <StartScreen
            onStart={start}
            loading={busy}
            error={error}
            savedChildren={savedChildren}
            onViewHistory={openHistory}
            onDeleteChild={deleteChild}
            onChangeAvatar={changeAvatar}
          />}

          {stage === 'history' && historyChild && <HistoryScreen child={historyChild} onBack={restart} onOpen={(item) => { setHistorical(item); setStage('historical_result'); }} />}

          {stage === 'historical_result' && historical && <ResultsScreen report={historical.report} sessionId={historical.id} childName={historical.childName} completedAt={historical.completedAt} historical onBackToHistory={() => setStage('history')} onRestart={restart} onChooseCategory={() => {}} onReassess={() => {}} remainingUnseen={0} busy={false} error={null} />}

          {stage === 'categories' && <CategoryScreen initialCategory={roundCategory} initialCount={roundLength} onSelect={chooseRound} onPreview={previewCategory} progress={progress} onReport={() => setStage('results')} onPlayZone={openPlayZone} onBack={restart} report={report} explored={explored} busy={busy} error={error} />}

          {stage === 'playzone' && (
            <PlayZoneScreen childName={child?.firstName} age={child?.age} progress={progress} onBack={() => setStage('categories')} onFinish={finishGame} />
          )}

          {stage === 'quiz' && test && (
            <QuizScreen test={test} onFinish={finish} onExit={leaveQuiz} submitting={busy} error={error} />
          )}

          {stage === 'results' && report && (
            <ResultsScreen
              report={report}
              sessionId={sessionId}
              childName={child?.firstName}
              reward={reward}
              onRestart={restart}
              onChooseCategory={chooseCategory}
              onReassess={reassess}
              onTryCategory={(trait, count) => void tryCategory(trait, count)}
              roundLength={roundLength}
              remainingUnseen={test?.remainingUnseen ?? 0}
              busy={busy}
              error={error}
            />
          )}
        </View>
        <BreakSheet visible={breakOpen} onClose={() => setBreakOpen(false)} />
      </SafeAreaView>
      </IdleGuard>
    </SafeAreaProvider>
  );
}

export default function App() {
  // Stripe and PayPal send parents to /thank-you after a support payment.
  const [thankYou, setThankYou] = useState(isThankYouPage);
  // Public pages Google Play and the App Store link to: no sign-in needed.
  const [legal, setLegal] = useState(isLegalPage);
  const home = () => { globalThis.history?.replaceState(null, '', '/'); setThankYou(false); setLegal(null); };
  if (thankYou) return <ThankYouScreen onContinue={home} />;
  if (legal) return <LegalScreen page={legal} onContinue={home} />;
  return <AuthProvider><KidCogApp /></AuthProvider>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  root: { flex: 1, backgroundColor: colors.bg },
});
